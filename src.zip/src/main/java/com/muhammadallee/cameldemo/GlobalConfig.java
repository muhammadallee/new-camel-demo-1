package com.muhammadallee.cameldemo;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class GlobalConfig {
    private String failureRestEndpoint;
}
